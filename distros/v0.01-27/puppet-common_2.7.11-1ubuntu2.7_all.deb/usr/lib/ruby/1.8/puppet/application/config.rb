require 'puppet/application/face_base'

class Puppet::Application::Config < Puppet::Application::FaceBase
end
