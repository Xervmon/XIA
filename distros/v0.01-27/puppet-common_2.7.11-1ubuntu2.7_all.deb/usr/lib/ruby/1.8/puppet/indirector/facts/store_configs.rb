require 'puppet/node/facts'
require 'puppet/indirector/store_configs'

class Puppet::Node::Facts::StoreConfigs < Puppet::Indirector::StoreConfigs
end
