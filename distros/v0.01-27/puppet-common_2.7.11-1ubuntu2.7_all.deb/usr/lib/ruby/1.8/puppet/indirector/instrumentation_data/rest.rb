require 'puppet/indirector/rest'
require 'puppet/indirector/instrumentation_data'

class Puppet::Indirector::InstrumentationData::Rest < Puppet::Indirector::REST
end
