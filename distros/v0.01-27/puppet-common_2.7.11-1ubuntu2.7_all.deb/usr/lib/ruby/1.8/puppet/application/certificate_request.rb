require 'puppet/application/indirection_base'

class Puppet::Application::Certificate_request < Puppet::Application::IndirectionBase
end
