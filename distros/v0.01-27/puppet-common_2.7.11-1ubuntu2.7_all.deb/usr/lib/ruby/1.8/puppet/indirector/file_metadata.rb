require 'puppet/file_serving/metadata'

# A stub class, so our constants work.
class Puppet::Indirector::FileMetadata # :nodoc:
end
