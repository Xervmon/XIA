require 'puppet/application/indirection_base'

class Puppet::Application::Report < Puppet::Application::IndirectionBase
end
