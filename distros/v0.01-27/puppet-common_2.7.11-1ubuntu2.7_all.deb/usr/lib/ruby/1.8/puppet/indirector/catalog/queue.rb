require 'puppet/resource/catalog'
require 'puppet/indirector/queue'

class Puppet::Resource::Catalog::Queue < Puppet::Indirector::Queue
end
