module Puppet::Module::Tool
  module Utils
    require 'puppet/module_tool/utils/interrogation'
  end
end
