module Puppet::FileSystem
  require 'puppet/file_system/path_pattern'
end
