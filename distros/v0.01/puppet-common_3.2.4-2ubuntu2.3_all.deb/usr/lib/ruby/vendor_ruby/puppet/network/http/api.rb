require 'puppet/network/http'

class Puppet::Network::HTTP::API
end
